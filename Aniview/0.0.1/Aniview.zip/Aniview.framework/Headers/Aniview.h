//
//  Aniview.h
//  Aniview
//
//  Created by Bogdan Susla on 12/27/19.
//  Copyright © 2019 Bogdan Susla. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "GCDWebServer.h"
#import "GCDWebServerResponse.h"
#import "GCDWebServerDataResponse.h"
#import "mamba.h"

//! Project version number for Aniview.
FOUNDATION_EXPORT double AniviewVersionNumber;

//! Project version string for Aniview.
FOUNDATION_EXPORT const unsigned char AniviewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Aniview/PublicHeader.h>


