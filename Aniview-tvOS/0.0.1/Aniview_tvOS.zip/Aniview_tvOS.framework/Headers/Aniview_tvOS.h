//
//  Aniview_tvOS.h
//  Aniview tvOS
//
//  Created by Bogdan Susla on 12/27/19.
//  Copyright © 2019 Bogdan Susla. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "GCDWebServer.h"
#import "GCDWebServerResponse.h"
#import "GCDWebServerDataResponse.h"
#import "mamba.h"

//! Project version number for Aniview_tvOS.
FOUNDATION_EXPORT double Aniview_tvOSVersionNumber;

//! Project version string for Aniview_tvOS.
FOUNDATION_EXPORT const unsigned char Aniview_tvOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Aniview_tvOS/PublicHeader.h>


